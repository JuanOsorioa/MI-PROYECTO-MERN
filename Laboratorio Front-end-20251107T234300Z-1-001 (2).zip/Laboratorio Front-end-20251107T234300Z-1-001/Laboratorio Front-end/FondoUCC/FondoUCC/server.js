// FondoUCC/server.js (Actualización con Transacciones)

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const connectDB = require('./src/config/db.config');
const { errorHandler, notFound } = require('./src/middleware/error.middleware');
const authRoutes = require('./src/routes/auth.routes');
const userRoutes = require('./src/routes/user.routes');
// 🚨 Importar nuevas rutas de Transacciones
const transactionRoutes = require('./src/routes/transaction.routes');

connectDB();
const app = express();
const PORT = process.env.PORT || 5000;

// Middlewares globales
app.use(express.json());
app.use(cors());

// 1. RUTAS (Endpoints)
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
// 🚨 Nueva ruta para Transacciones
app.use('/api/transactions', transactionRoutes);

// Ruta de prueba
app.get('/', (req, res) => {
    res.status(200).json({
        message: "API Fondo UCC en funcionamiento. Transacciones listas para probar."
    });
});

// 2. MANEJO DE ERRORES:
app.use(notFound);
app.use(errorHandler);

// Arrancar el servidor
app.listen(PORT, () => {
    console.log(`🚀 Servidor Express escuchando en el puerto ${PORT}`);
    console.log(`URL: http://localhost:${PORT}`);
});