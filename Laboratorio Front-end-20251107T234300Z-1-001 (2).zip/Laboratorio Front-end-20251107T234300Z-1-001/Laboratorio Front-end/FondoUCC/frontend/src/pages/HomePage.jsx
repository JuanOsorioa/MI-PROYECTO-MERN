// frontend/src/pages/HomePage.jsx

const HomePage = () => {
  return (
    <div>
      <h1>Bienvenido al Fondo UCC</h1>
      <p>Por favor, inicia sesión para acceder a tu balance y transacciones.</p>
    </div>
  );
};

export default HomePage;