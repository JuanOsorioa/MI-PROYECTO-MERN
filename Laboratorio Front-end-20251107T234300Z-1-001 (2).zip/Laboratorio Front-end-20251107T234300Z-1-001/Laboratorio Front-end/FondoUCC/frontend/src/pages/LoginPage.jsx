// frontend/src/pages/LoginPage.jsx

const LoginPage = () => {
  return (
    <div>
      <h2>Iniciar Sesión</h2>
      <p>Aquí irá el formulario de Login.</p>
    </div>
  );
};

export default LoginPage;