// frontend/src/pages/RegisterPage.jsx

const RegisterPage = () => {
  return (
    <div>
      <h2>Registrar Nuevo Socio</h2>
      <p>Aquí irá el formulario de Registro.</p>
    </div>
  );
};

export default RegisterPage;